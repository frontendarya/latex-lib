# grigoreva_python_hw

```bash
pip install -r requirements.txt
